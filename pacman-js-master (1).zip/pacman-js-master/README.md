# pacman-js

[![Code Coverage](https://img.shields.io/badge/coverage-100%25-brightgreen.svg)](https://github.com/bward2/pacman-js/blob/master/coverage/coverage-summary.json)
[![Code Style](https://img.shields.io/badge/code%20style-airbnb-brightgreen.svg)](https://github.com/airbnb/javascript)

Pacman clone made with Javascript, HTML, and CSS.

### _**[Play it!](https://bward2.github.io/pacman-js/)**_

🍒🍓🍊🍎🍈👾🔔🔑

## Development Instructions

This project makes use of _**[NodeJS](https://nodejs.org/en/)**_. Download it, then clone this repo and run the following commands:

1. `npm i` (Installs necessary packages for development)
1. `npm run watch` (Watches changes to JS and SCSS files for continuous compilation)
1. `npm run serve` (Hosts the files locally)

The game can now be accessed at _**http://127.0.0.1:8080/index**_

This project also utilizes _**[Husky](https://github.com/typicode/husky)**_ to enforce best coding practices. The current thresholds are 0 linting errors upon commits (following Airbnb's standard), and 100% unit test code coverage upon pushes.

Feel free to submit PRs and/or report any issues you find! 😃
